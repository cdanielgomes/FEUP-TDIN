import ErrorHandler from './ErrorHandler';

export default ErrorHandler;
