import IssueCard from "./IssueCard";
export default IssueCard;
