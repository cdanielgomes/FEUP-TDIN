using System;

namespace Solver {
    public class Question {
        public string Text;
        public string Answer;
        public string State;
        public string Date;
        public string Department;
    }
}